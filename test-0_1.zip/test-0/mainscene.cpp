#include "mainscene.h"
#include "ui_mainscene.h"
#include<QPaintEvent>
#include <QWidget>
#include <QPainter>     //画家
#include <QMouseEvent>
#include<QPushButton>
#include<QTimer>
#include <QFileDialog>
#include<QVector>
#include<QDebug>
#include<QPixmap>
#include<tower.h>
MainScene::MainScene(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainScene)
{
    ui->setupUi(this);

    timer=new QTimer();
    this->setFixedSize(800,600);
    this->setWindowIcon(QPixmap(":/image/761.ico"));//图标
    this->setWindowTitle("Overwatch");
    //关闭
    connect(ui->actionquit,&QAction::triggered,[=](){this->close();});
    //造塔基

    int i,m=0;
    for(i=0;i<4;i++)
    {
    m=65+135*i;
    btn[i] =new QPushButton("塔位",this);
    btn[i]->setGeometry(m,227,40,65);
    }
    m=0;
    for(i=4;i<8;i++)
    {
        m=65+135*(i-4);
        btn[i] =new QPushButton("塔位",this);
        btn[i]->setGeometry(m,500,40,65);
    }
    for(i=0;i<8;i++)
    {

        connect(btn[i],&QPushButton::clicked,[=](){
            if(num>10)
            {
                btn[i]->setText("炮塔");
                num=num-10;
            }
        });
    };//修建炮台
//计时器
     timer->start(1000);
    connect(timer, SIGNAL(timeout()),this, SLOT(Mytimer()));
    //设置鼠标追踪
//    setMouseTracking(true);

}
int MainScene::num=0;
void MainScene::Mytimer()
{

    ui->lcdNumber->display(QString::number(num++));

}//计时器函数
void MainScene::paintEvent(QPaintEvent* )
{
    QPainter painter(this);
    QPixmap pix(":/image/fanggemap1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);
}//画背景图

//鼠标进入事件
void MainScene::enterEvent(QEvent *event)
{

}
//鼠标离开
void MainScene::leaveEvent(QEvent *event)
{

}
//鼠标按下
void MainScene::mousePressEvent(QMouseEvent *ev)
{
    QString str =QString("press x=%1 y=%2 globalx=%3 globaly=%4").arg(ev->x()).arg(ev->y()).arg(ev->globalX()).arg((ev->globalY()));
    qDebug()<<str;
}
//鼠标释放
void MainScene::mouseReleaseEvent(QMouseEvent *ev)
{

}
//鼠标移动
void MainScene::mouseMoveEvent(QMouseEvent *event)
{

}

//int MainScene::check()
//{
//    if(num>10)
//    {
//        btn[jo]->setText("炮塔");
//        num=num-10;
//    }
/*}*///炮台修建
//int MainScene::setmap(int nu)
//{
//    if(nu==1)
//    {

//        map={

//        }
//        ;
//    }
/*}*///地图
MainScene::~MainScene()
{
    delete ui;
}

