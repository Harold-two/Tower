#ifndef MAINSCENE_H
#define MAINSCENE_H

#include <QMainWindow>
#include<QLabel>
#include<QPushButton>
#include<QTimer>
#include<QPaintEvent>
#include <QWidget>
#include <QPainter>     //画家
#include <QMouseEvent>
#include <QFileDialog>
#include<QVector>
#include<QDebug>
#include<QPixmap>
#include<tower.h>
#include<QToolButton>
QT_BEGIN_NAMESPACE
namespace Ui { class MainScene; }
QT_END_NAMESPACE

class MainScene : public QMainWindow
{
    Q_OBJECT

public:
    MainScene(QWidget *parent = nullptr);
    ~MainScene();
    void paintEvent(QPaintEvent *);

    int setmap(int nu);
    static int num;
    QPushButton *btn[10];
    //鼠标进入事件
    void enterEvent(QEvent *event);
    //鼠标离开
    void leaveEvent(QEvent *event);
    //鼠标按下
    virtual void mousePressEvent(QMouseEvent *ev);
    //鼠标释放
    virtual void mouseReleaseEvent(QMouseEvent *ev);
    //鼠标移动
    virtual void mouseMoveEvent(QMouseEvent *event) ;
//    static int jo;
public slots:
    void Mytimer();
//    int check();

private:
    Ui::MainScene *ui;
    QTimer *timer;
    int map[16][16]={};
    QList<Tower*>tower_list;

};

#endif // MAINSCENE_H
