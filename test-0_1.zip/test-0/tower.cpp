#include "tower.h"

Tower::Tower(QObject *parent) : QObject(parent)
{

}
