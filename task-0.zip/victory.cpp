#include "victory.h"
#include "ui_victory.h"
#include<QLabel>
#include<QMediaPlayer>
Victory::Victory(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Victory)
{
    ui->setupUi(this);
    //提示胜利标签
    this->setFixedSize(800,600);
    QMediaPlayer *victorySound = new QMediaPlayer(this);
    victorySound->setMedia(QUrl("qrc:/image/Victory.mp3"));
    victorySound->setVolume(100);
    victorySound->play();

}

Victory::~Victory()
{
    delete ui;
}
