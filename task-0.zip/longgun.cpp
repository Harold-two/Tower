#include "longgun.h"

longgun::longgun(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight,int swi)
{
    //初始化成员变量，这里不能用初始化列表
    if(swi==0)
    {
    mx = x, my = y;
    BaseImgPath = QString(":/image/mod5.jpg");
    DefImgPath = QString(":/image/76.jpg");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 200;    //射程

    BullPath = QString(":/image/feidan.png");
    bullwidth = 30, bullheight = 30;           //子弹大小

    attack = 100;    //攻击力
    setspeed(24);
    setintime(5);
//    ExplRangeWidth = 65;    //爆炸效果宽高
//    ExplRangeHeight = ExplRangeWidth;
    }
    else if(swi==1)//黑百合
    {
        mx = x, my = y;
        BaseImgPath = QString(":/image/mod5.jpg");
        DefImgPath = QString(":/image/blackwindow.jpg");
        width = Fwidth, height = Fheight;
        UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

        Range = 300;    //射程

        BullPath = QString(":/image/Shells1.png");
        bullwidth = 10, bullheight = 10;           //子弹大小

        attack = 200;    //攻击力
        setspeed(50);    //设置子弹速度
        setintime(10);  //设置攻击间隔
//        ExplRangeWidth = 65;    //爆炸效果宽高
//        ExplRangeHeight = ExplRangeWidth;
    }
    else if(swi==2)//麦克雷
    {
        mx = x, my = y;
        BaseImgPath = QString(":/image/mod5.jpg");
        DefImgPath = QString(":/image/macree.jpg");
        width = Fwidth, height = Fheight;
        UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

        Range = 200;    //射程

        BullPath = QString(":/image/Shells0.png");
        bullwidth = 20, bullheight = 20;           //子弹大小

        attack = 150;    //攻击力
        setspeed(40);    //设置子弹速度
        setintime(7);  //设置攻击间隔
//        ExplRangeWidth = 65;    //爆炸效果宽高
//        ExplRangeHeight = ExplRangeWidth;
    }
    else if(swi==3)
    {
        mx = x, my = y;
        BaseImgPath = QString(":/image/mod5.jpg");
        DefImgPath = QString(":/image/bastion.jpg");
        width = Fwidth, height = Fheight;
        UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

        Range = 180;    //射程

        BullPath = QString(":/image/Shells2.png");
        bullwidth = 35, bullheight = 35;           //子弹大小

        attack = 300;    //攻击力
        setspeed(35);    //设置子弹速度
        setintime(7);  //设置攻击间隔
//        ExplRangeWidth = 65;    //爆炸效果宽高
//        ExplRangeHeight = ExplRangeWidth;
    }
}
