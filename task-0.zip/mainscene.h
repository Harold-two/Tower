#ifndef MAINSCENE_H
#define MAINSCENE_H

#include <QMainWindow>
#include<QLabel>
#include<QPushButton>
#include<QTimer>
#include<QPaintEvent>
#include <QWidget>
#include <QPainter>     //画家
#include <QMouseEvent>
#include <QFileDialog>
#include<QVector>
#include<QDebug>
#include<QPixmap>
#include<monster.h>
#include<QToolButton>
#include<defensetower.h>
#include<takeng.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainScene; }
QT_END_NAMESPACE

class MainScene : public QMainWindow
{
    Q_OBJECT

public:
    MainScene(QWidget *parent = nullptr);
    ~MainScene();
    void paintEvent(QPaintEvent *);//画图
    static int num;
    void setifto(int to)
    {
        ifto=to;
    }
    int getifto()
    {
        return ifto;
    }
    QPushButton *btn[10];



public slots:
    void Mytimer();
signals :


private:
    Ui::MainScene *ui;
    QTimer *timer;
    QVector<monster*> MonsterVec;           //怪物数组
    QVector<defensetower*> DefeTowerVec; //重要防御塔父类数组
    QVector<takeng*> TowerPitVec;  //防御塔坑数组
    int map[16][16]={};
    QPushButton *btns[16][16];
    int counter=0;
    int life=10;
    bool DisplayAllRange = false;  //标识是否显示所有防御塔的攻击范围
    void IrodMonsProgDefa(CoorStr**, CoorStr**, CoorStr*, int*); //预设两条路产生怪物方案函数
    CoorStr *homecoor = new CoorStr(0, 0);  //记录家的坐标，从地图中自动获取
    void DrawMonster(QPainter&);
    void DrawDefenseTower(QPainter&);
    void DrawRangeAndUpgrade(QPainter& painter);
    int DisplayRangeX, DisplayRangeY;       //用于记录显示范围的防御塔的坐标
    bool DisplayRange = false;              //用于显示防御塔攻击范围
    QPushButton *heros[8];
    int ifto=false;
    bool clo=0;//关闭窗口用
};

#endif // MAINSCENE_H
