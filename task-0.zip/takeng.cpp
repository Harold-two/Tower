#include "takeng.h"
#include<QPaintEvent>
#include <QWidget>
#include <QPainter>     //画家
#include <QMouseEvent>
#include<QPushButton>
#include<QTimer>
#include <QFileDialog>
#include<QVector>
#include<QDebug>
#include<QPixmap>
//#include<tower.h>
#include<QIcon>
#include<mainwindow.h>
//构造
takeng::takeng(int x, int y, int width, int height)
    : mx(x), my(y), mwidth(width), mheight(height) {}

int takeng::GetX() const     //获取横坐标
{
    return mx;
}

int takeng::GetY() const     //获取横坐标
{
    return my;
}

int takeng::GetWidth() const //获取宽
{
    return mwidth;
}

int takeng::GetHeight() const //获取高
{
    return mheight;
}
