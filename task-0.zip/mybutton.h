#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QMainWindow>
#include<QPushButton>
#include<QMouseEvent>
class MyButton : public QPushButton
{
    Q_OBJECT
public:
    explicit MyButton(QWidget *parent = nullptr);
//    void enterEvent(QEvent *e); //鼠标进入事件
//    void leaveEvent(QEvent *e);//鼠标离开事件
    //normalImg 代表正常显示的图片
        //pressImg  代表按下后显示的图片，默认为空
        MyButton(QString normalImg,QString pressImg = "");
        void zoom1();
        void zoom2();
        QString normalImgPath;  //默认显示图片路径
        QString pressedImgPath; //按下后显示图片路径
signals:

};

#endif // MYBUTTON_H
