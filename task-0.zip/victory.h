#ifndef VICTORY_H
#define VICTORY_H

#include <QMainWindow>

namespace Ui {
class Victory;
}

class Victory : public QMainWindow
{
    Q_OBJECT

public:
    explicit Victory(QWidget *parent = nullptr);
    ~Victory();

private:
    Ui::Victory *ui;
};

#endif // VICTORY_H
