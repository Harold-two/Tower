#include "globalstruct.h"

globalstruct::globalstruct(QWidget *parent) : QMainWindow(parent)
{

}
