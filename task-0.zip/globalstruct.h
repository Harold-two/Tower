#ifndef GLOBALSTRUCT_H
#define GLOBALSTRUCT_H
#include <QString>

//坐标结构
struct CoorStr
{
    int x;
    int y;

    CoorStr(int x1, int y1) : x(x1), y(y1) {}
};

//子弹结构
struct BulletStr
{
    CoorStr coor;       //子弹坐标
    int k = 0, b = 0;   //用于计算出子弹路径函数
    bool dirflag = false;   //移动方向标识

    BulletStr(CoorStr fcoor) : coor(fcoor) {}

    int GetX()  const
    {
        return coor.x;
    }

    int GetY() const
    {
        return coor.y;
    }
};
#endif // GLOBALSTRUCT_H
