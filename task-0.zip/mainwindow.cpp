#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<mainscene.h>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QIcon>
#include<mybutton.h>
#include<QSound>
#include<QMediaPlayer>
#include<QLabel>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFixedSize(1000,600);
    this->setWindowIcon(QPixmap(":/image/overwatch1.jpg"));
    this->setWindowTitle("overwatch");
    QMediaPlayer *startSound = new QMediaPlayer(this);
    startSound->setMedia(QUrl("qrc:/image/Rally.mp3"));
    startSound->setVolume(60);
    startSound->play();
    MyButton *pushButton=new MyButton(this);
    pushButton->setGeometry(390,110,211,51);
    pushButton->setIcon(QIcon(":/image/timg3.jpg"));
    pushButton->setFixedSize(200,65);
    pushButton->setIconSize(QSize(200,65));
    MyButton *pb[4];
    for(int i=0;i<3;i++)
    {
        pb[i]=new MyButton(this);
        pb[i]->setGeometry(320+i*120,200,100,50);
        pb[i]->setFixedSize(100,50);
        pb[i]->hide();
        connect(pb[i],&QPushButton::clicked,[=](){
            pb[i]->zoom1();
            pb[i]->zoom2();
            QTimer::singleShot(100, this,[=](){
                MainScene *scene=new MainScene(this);
                startSound->stop();
                scene->show();
                this->hide();
                levelnumber=i;
                    });//延时0.1秒切换界面
        });
    }
    QLabel *la=new QLabel(this);
    la->setGeometry(330,300,500,50);
    la->setText("本游戏金钱仅仅随着时间增加");
    la->setFont(QFont("微软雅黑", 12));
    la->hide();
    QLabel *la1=new QLabel(this);
    la1->setGeometry(270,350,500,50);
    la1->setText("英雄所需费用：76与百合5元，麦克雷10元，堡垒20元");
    la1->setFont(QFont("微软雅黑", 12));
    la1->hide();
    pb[3]=new MyButton(this);
    pb[3]->setGeometry(320+3*120,200,100,50);
    pb[3]->setFixedSize(100,50);
    pb[3]->hide();
    connect(pb[3],&QPushButton::clicked,[=](){
        la->show();
        la1->show();
    });
    pb[0]->setText("第一关");pb[1]->setText("第二关");pb[2]->setText("第三关");pb[3]->setText("帮助");
    connect(pushButton,&QPushButton::clicked,[=]()
    {
        pushButton->zoom1();
        pushButton->zoom2();
        QTimer::singleShot(100, this,[=](){
        for(int i=0;i<4;i++)
        {
            pb[i]->show();
        }});
    });//延时0.1秒切换界面
}
int MainWindow::levelnumber=0;
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent* )
{
    QPainter painter(this);
    QPixmap pix(":/image/overwatch3.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pix);
}//画背景图
void MainWindow::on_pushButton_clicked()
{
    MainScene *scene=new MainScene(this);
    scene->show();
    this->hide();
    levelnumber=0;
}//得想个办法删了他
