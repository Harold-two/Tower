#ifndef LONGGUN_H
#define LONGGUN_H

#include <QMainWindow>
#include<defensetower.h>
class longgun : public defensetower
{
    Q_OBJECT
public:
    explicit longgun(QWidget *parent = nullptr);

signals:
public:
    longgun(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight,int swi);
    void setspeed(const int sp)
    {
        speed=sp;
    }
    void setintime(const int it)
    {
        intime=it;
    }
};

#endif // LONGGUN_H
